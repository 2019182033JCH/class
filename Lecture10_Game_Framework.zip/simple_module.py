print("The value of __name__ is '" + __name__ + "'.")
